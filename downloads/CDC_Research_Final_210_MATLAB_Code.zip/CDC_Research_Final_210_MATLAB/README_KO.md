# CDC Research Final: 210조건 MATLAB 전체 코드

완료된 210조건 × 타이어 마모 5종 계산에 사용한 MATLAB 15개와 Native C++ 소스 2개를 포함합니다. 동역학·판정·옵션 소스는 실제 계산용 동결 소스와 SHA-256이 일치합니다.

## MATLAB 실행

압축 해제 후 이 README가 있는 폴더를 MATLAB Current Folder로 설정합니다.

```matlab
run_cdc_research('selftest');
R = run_cdc_research('full', struct('engine','mcode'));
```

MATLAB M-code 실행에는 C++ 컴파일이 필요 없습니다. 기본 저장 폴더는 `results_new_full`입니다. 다른 위치에 저장하려면 다음과 같이 실행합니다.

```matlab
R = run_cdc_research('full', struct('engine','mcode', ...
    'output_dir',fullfile(pwd,'results_210')));
```

`run_cdc_research`를 인자 없이 실행하면 전체 210조건이 아닌 pilot 모드입니다. 전체 계산에는 위의 `'full'` 인자를 지정하세요. 같은 결과 폴더에서는 기존 결과와 마모별 체크포인트를 확인하여 이어서 계산합니다. 설정을 바꾼 실험은 별도 출력 폴더를 사용하세요.

## 이번에 완료한 계산과의 관계

서버에서는 GNU Octave 9.4와 Native C++ 가속 엔진을 사용했습니다. M-code와 Native의 동역학 및 실제 10초 궤적 판정·진단 비교를 통과했습니다. M-code 실행 시간은 가속 엔진보다 깁니다. 서로 다른 MATLAB/Octave/컴파일러 환경의 부동소수점 차이로 수치 경계점 판정이 달라질 수 있습니다.

C++17/OpenMP 지원 컴파일러가 있다면 다음과 같이 동일한 가속 엔진을 빌드하여 실행할 수 있습니다.

```matlab
cdc_build_native;
R = run_cdc_research('full', struct('engine','native'));
```

실행 바이너리는 포함하지 않으며 `native` 폴더의 원본 소스를 해당 컴퓨터에서 빌드합니다.

## 계산 조건

- 속도: 50, 60, 70, 80, 90, 100 km/h. 각 궤적에서 차속 고정.
- 마찰계수: 0.9, 0.8, 0.7, 0.6, 0.5. 기존 MF 타이어의 mu/0.9 진폭 스케일링 유지.
- 전륜 휠 조향각: 0, 0.5, 1, 1.5, 2, 2.5, 3°. 후륜 0°.
- 타이어 마모 [FL FR RL RR]: [0 0 0 0], [25 25 0 0], [50 50 25 25], [0 0 25 25], [25 25 50 50].
- 스프링 네 코너 30,790 N/m, CDC 네 코너 950 mA. MRf=0.8613, MRr=0.7970. 별도 피드백 없음.
- 초기 횡속도 −3:0.1:3 m/s, 초기 요레이트 −1.5:0.025:1.5 rad/s의 61×121 격자.
- 롤각 및 다른 숨은 초기상태는 각 조건·마모의 정상선회점(trim)에서 가져옴. 롤·현가를 포함한 32상태 동역학 유지.
- 시간간격 0.0005초. 같은 궤적에서 5초·10초 판정, 마지막 1초 구간으로 복귀 판정.

## MAT 결과와 그림

파일명 예: `research_80kph_mu0.9_delta+2_I950_950_950_950_trim.mat`

MAT 변수는 `RESEARCH2D`이며 마모별 결과는 `RESEARCH2D.CASE{1}`부터 `{5}`입니다.

```matlab
file = fullfile(pwd,'results_new_full', ...
    'research_80kph_mu0.9_delta+2_I950_950_950_950_trim.mat');
D = load(file,'RESEARCH2D');
C = D.RESEARCH2D.CASE{1};
F5 = C.masks.final(:,:,1);
F10 = C.masks.final(:,:,2);
area = C.region.cell_area;
plot_cdc_research({file},1,'final');
```

주 결과 `masks.final`은 정적 handling 기준 H 안에서 시작해, H를 한 번도 벗어나지 않고 경로 제약을 만족하면서 정상선회점으로 복귀한 초기점입니다. H 밖의 초기점은 계산하지 않으며 불안정으로 해석하면 안 됩니다. `recoverable_on_reference`는 도중 H 이탈을 허용한 복귀 비교이고, `guarded_final`과 `prepeak_final`은 각각 추가 요레이트 정책과 타이어 복원기울기 조건을 적용합니다.

`region.cell_mask`와 `region.cell_area`는 10초 final의 네 꼭짓점과 실제 중심점 시뮬레이션이 통과한 격자 셀입니다. 볼록껍질 채우기나 영역 이동은 사용하지 않습니다. 결과는 유한시간 표본 판정이며 연속영역·점근 안정성·불변집합의 수학적 증명은 아닙니다.

`SOURCE_SHA256.json`은 코드 파일 17개의 SHA-256 목록입니다. 이 ZIP에는 MAT 결과를 넣지 않았습니다. 완료된 MAT·그림·수치 요약은 다음 GitHub 폴더에 있습니다.
https://github.com/yodagil/suspension/tree/main/results/cdc_research_final
