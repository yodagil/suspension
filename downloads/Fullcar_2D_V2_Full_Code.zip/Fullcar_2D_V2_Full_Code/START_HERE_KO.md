# V2 Full-car 전체 소스 코드

압축을 푼 뒤 MATLAB Current Folder를 fullcar_2d_v2/matlab 폴더로 지정하세요.

먼저 자체 검사:
    run_fullcar_2d_v2('selftest');

전체 210조건 × 타이어 마모 5종 실행:
    run_fullcar_2d_v2('full');

일부 조건 확인:
    run_fullcar_2d_v2('pilot');  % 80 km/h, mu=0.9, -2/0/+2 deg, 정상 타이어
    run_fullcar_2d_v2('wear');   % 같은 조건의 마모 5종

차량·타이어·전후륜 CDC 선도는 M코드에 내장되어 있습니다.
32상태 Full-car와 롤·현가 운동을 유지합니다. 초기조건 격자는 횡속도 49개 × 요레이트 81개이고,
숨은 초기상태와 롤각은 각 조건의 정상선회점(trim)에 맞춥니다. 5초·10초 판정을 함께 저장합니다.
MATLAB 결과는 M코드 폴더 옆 results_fullcar_v2_full에 저장됩니다.
기본 M-code 실행에는 C++ 실행 파일이나 별도 MAT/TIR 데이터가 필요하지 않습니다.
파일 SHA-256 검사는 MATLAB 기본 Java VM을 사용합니다. MATLAB R2016b 이상을 사용하세요.

이 ZIP은 현재 클라우드 계산과 같은 모델·설정을 포함합니다. 클라우드는 독립 검증을 마친
C++ 가속 경로를 사용하며, MATLAB 직접 실행은 더 느립니다. 가속 소스와 진행/검증/그림/게시용
Python 코드도 포함했습니다. 가속 빌드는 fullcar_2d_v2/native/README.md를 참고하세요.

전체 설명: fullcar_2d_v2/README_KO.md
소스 무결성: SOURCE_SHA256.json
이 ZIP에는 계산 결과 MAT나 플랫폼별 실행 파일은 포함하지 않습니다.
